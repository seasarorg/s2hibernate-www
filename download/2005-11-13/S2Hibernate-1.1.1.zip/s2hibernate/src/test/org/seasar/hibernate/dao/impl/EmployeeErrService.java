package test.org.seasar.hibernate.dao.impl;

import org.seasar.hibernate.HibernateRuntimeException;

import examples.hibernate.dao.EmployeeAutoDao;

import examples.hibernate.entity.Employee;

public class EmployeeErrService implements EmployeeService {
	EmployeeAutoDao dao_;

	public EmployeeErrService(EmployeeAutoDao dao) {
		dao_ = dao;		
	}
	
	public void execute(){
		
		Employee emp = new Employee();
		emp.setEmpno( new Integer(7900));
		emp.setEname("test");
		emp.setDeptno( new Integer(10) );
					
		dao_.save( emp ) ;
		
		throw new HibernateRuntimeException(null);		
		
	}
}
