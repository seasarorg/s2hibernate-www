package examples.hibernate.dto;

import examples.hibernate.entity.Employee;

/**
 * @author kenichi_okazaki
 */
public class EmployeeSimpleDto extends Employee {

	private String orderBy;
	
	/**
	 * @return Returns the orderBy.
	 */
	public String getOrderBy() {
		return orderBy;
	}
	/**
	 * @param orderBy The orderBy to set.
	 */
	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}
}
