package org.seasar.hibernate.dao.impl;

import java.lang.reflect.Method;

import net.sf.hibernate.Criteria;
import net.sf.hibernate.HibernateException;

import org.seasar.hibernate.S2Session;
import org.seasar.hibernate.S2SessionFactory;
import org.seasar.hibernate.dao.criteria.CriteriaCommand;

/**
 * @author kenichi_okazaki 
 */
public class AutoArgsQueryCommand extends AbstractAutoQueryCommand {

	public AutoArgsQueryCommand(S2SessionFactory s2sessionFactory,Class beanClass, Method method) {
		super(s2sessionFactory, beanClass,method);
	}


	protected Criteria getArgsCriteria(S2Session s2session, Object[] args) throws HibernateException {

		ArgsMetaData argsMeta = getArgsMeta();
		String[] argNames = argsMeta.getArgNames();
		
		Criteria criteria = s2session.createCriteria( getBeanClass() );
		for (int i = 0; i < argsMeta.getArgsCount(); i++) {
			Object value = argsMeta.getValue(args,i);
			if (value != null) {
				CriteriaCommand criteriaCommand = (CriteriaCommand)criteriaCommandList_.get(i);
				criteria = criteriaCommand.getCriteria( criteria, value ) ;
			}
		}
		return criteria;
	}





}