package org.seasar.hibernate.dao.criteria;

import net.sf.hibernate.Criteria;

/**
 * @author kenichi_okazaki
 *
 */
public interface CriteriaCommand {
	public abstract Criteria getCriteria(Criteria criteria,Object value) ;
	public String getDtoFieldName() ;
}