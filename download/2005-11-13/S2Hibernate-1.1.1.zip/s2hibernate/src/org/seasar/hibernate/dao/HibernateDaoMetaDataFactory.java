package org.seasar.hibernate.dao;

/**
 * @author kenichi_okazaki
 */
public interface HibernateDaoMetaDataFactory {
	public HibernateDaoMetaData getDaoMetaData(Class daoClass);
}