package org.seasar.hibernate;

import net.sf.hibernate.HibernateException;

import org.seasar.framework.exception.SRuntimeException;

/**
 * @author higa
 *
 * HibernateException�����b�v������s����O�ł��B
 */
public final class HibernateRuntimeException extends SRuntimeException {

	public HibernateRuntimeException(HibernateException cause) {
		super("EHBN0001", new Object[] { cause }, cause);
	}
}
