package org.seasar.hibernate3.dao.criteria;

import org.hibernate.Criteria;

/**
 * @author kenichi_okazaki
 */
public interface CriteriaCommand {
    public abstract Criteria getCriteria(Criteria criteria, Object value);

    public String getDtoFieldName();
}
