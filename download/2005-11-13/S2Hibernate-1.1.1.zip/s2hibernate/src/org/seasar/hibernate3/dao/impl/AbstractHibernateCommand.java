package org.seasar.hibernate3.dao.impl;

import org.hibernate.Session;
import org.seasar.hibernate3.S2SessionFactory;
import org.seasar.hibernate3.dao.HibernateCommand;

/**
 * @author kenichi_okazaki
 *
 */
public abstract class AbstractHibernateCommand implements HibernateCommand {

	private S2SessionFactory s2sessionFactory_;
	
	public AbstractHibernateCommand(S2SessionFactory s2sessionFactory) {
		s2sessionFactory_ = s2sessionFactory;
	}
	
	public Session getSession() {
		return s2sessionFactory_.getSession();
	}
}
