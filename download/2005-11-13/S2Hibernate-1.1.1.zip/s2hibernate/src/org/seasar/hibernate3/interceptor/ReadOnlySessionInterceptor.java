package org.seasar.hibernate3.interceptor;

import org.aopalliance.intercept.MethodInvocation;
import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.seasar.framework.aop.interceptors.AbstractInterceptor;
import org.seasar.hibernate3.S2SessionFactory;

/**
 * @author koichik
 */
public class ReadOnlySessionInterceptor extends AbstractInterceptor {
    private S2SessionFactory sessionFactory;

    public void setSessionFactory(S2SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Object invoke(MethodInvocation invocation) throws Throwable {
        Session session = sessionFactory.getSession();
        session.setFlushMode(FlushMode.NEVER);

        return invocation.proceed();
    }
}
