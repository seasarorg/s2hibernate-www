package org.seasar.hibernate3.dao.impl;

import org.hibernate.Session;
import org.seasar.hibernate3.S2SessionFactory;

/**
 * @author kenichi_okazaki 
 */
public class UpdateCommand extends AbstractHibernateCommand  {

	public UpdateCommand(S2SessionFactory s2sessionFactory) {
		super(s2sessionFactory);
	}

	/* (�� Javadoc)
	 * @see org.srasar.hibernate.dao.HibernateCommand#execute(org.seasar.hibernate.S2Session, java.lang.Object[])
	 */
	public Object execute( Object[] args) {
		Session session = getSession();
		session.update( args[0]);
		return null;
	}

}
