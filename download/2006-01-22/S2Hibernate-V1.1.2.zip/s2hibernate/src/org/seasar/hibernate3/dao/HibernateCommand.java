package org.seasar.hibernate3.dao;

/**
 * @author kenichi_okazaki
 */
public interface HibernateCommand {
	
	public Object execute( Object[] args);
}
