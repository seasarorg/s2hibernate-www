package org.seasar.hibernate3.dao.criteria;

/**
 * @author kenichi_okazaki
 */
public abstract class abstractCriteriaCommand implements CriteriaCommand {

    protected String fieldName_;
    protected String dtoFieldName_;

    public abstractCriteriaCommand(String fieldName, String dtoFieldName) {
        fieldName_ = fieldName;
        dtoFieldName_ = dtoFieldName;
    }

    /**
     * @return Returns the dtoFieldName.
     */
    public String getDtoFieldName() {
        return dtoFieldName_;
    }
}
