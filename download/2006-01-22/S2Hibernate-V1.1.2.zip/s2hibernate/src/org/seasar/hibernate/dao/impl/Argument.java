package org.seasar.hibernate.dao.impl;

import org.seasar.framework.util.StringUtil;

/**
 * @author kenichi_okazaki
 *
 */
public class Argument {
	private String fieldName;
	private String expression;
	private String dtoFieldName;
	
	public Argument(String argument) {
		String[] arguments = StringUtil.split(argument, " ");
		
		fieldName 	= arguments[0];

		if(arguments.length == 1){
			expression = "";
		}else{
			expression= arguments[1];
		}
		
		if(arguments.length == 3){
			dtoFieldName=arguments[2];
		}else{
			dtoFieldName= fieldName;	
		}
		
	}
	
	public String getDtoFieldName() {
		return dtoFieldName;
	}
	public void setDtoFieldName(String dtoFieldName) {
		this.dtoFieldName = dtoFieldName;
	}

	public String getExpression() {
		return expression;
	}
	public void setExpression(String expression) {
		this.expression = expression;
	}

	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
}
