package org.seasar.hibernate;

import net.sf.hibernate.HibernateException;

import org.seasar.framework.exception.SRuntimeException;

/**
 * @author higa
 *
 * HibernateException�����b�v������s����O�ł��B
 */
public final class HibernateRuntimeException extends SRuntimeException {
    private static final long serialVersionUID = 1L;

    public HibernateRuntimeException(HibernateException cause) {
		super("EHBN0001", new Object[] { cause }, cause);
	}
}
