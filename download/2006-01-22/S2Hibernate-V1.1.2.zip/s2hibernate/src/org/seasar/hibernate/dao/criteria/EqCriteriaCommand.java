package org.seasar.hibernate.dao.criteria;

import net.sf.hibernate.Criteria;
import net.sf.hibernate.expression.Expression;

/**
 * @author kenichi_okazaki
 *
 */
public class EqCriteriaCommand extends abstractCriteriaCommand {

	/**
	 * @param fieldName
	 * @param dtoFieldName
	 */
	public EqCriteriaCommand(String fieldName,String dtoFieldName) {
		super(fieldName, dtoFieldName);
	}

	/* (non-Javadoc)
	 * @see org.seasar.hibernate.dao.criteria.CriteriaCommand#getCriteria(net.sf.hibernate.Criteria, java.lang.Object)
	 */
	public Criteria getCriteria(Criteria criteria,Object value) {

		return criteria.add( Expression.eq(fieldName_ , value));
	}


}
