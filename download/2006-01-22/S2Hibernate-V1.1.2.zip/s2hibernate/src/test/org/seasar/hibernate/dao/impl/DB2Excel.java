package test.org.seasar.hibernate.dao.impl;

import org.seasar.extension.dataset.impl.SqlReader;
import org.seasar.extension.dataset.impl.XlsWriter;
import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.S2ContainerFactory;

public class DB2Excel {

	  private static final String PATH =
        "test/org/seasar/hibernate/dao/impl/Db2Excel.dicon";
        
    public static void main(String[] args) {
        S2Container container = S2ContainerFactory.create(PATH);
        container.init();
        try {

        	SqlReader reader = (SqlReader)
                container.getComponent(SqlReader.class);

            XlsWriter writer = (XlsWriter)
                container.getComponent(XlsWriter.class);
  
            writer.write(reader.read());
            
        } finally {
            container.destroy();
        }
        System.out.println("end");
    }
}
