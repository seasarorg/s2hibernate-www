package examples.hibernate.entity;

import java.io.Serializable;
import java.util.Set;

public class Department implements Serializable {
    private static final long serialVersionUID = 1L;

    private int deptno;

    private String dname;

    private String loc;
    
	private Set employee ;
	
    public Department() {
    }

    public int getDeptno() {
        return this.deptno;
    }

    public void setDeptno(int deptno) {
        this.deptno = deptno;
    }

    public java.lang.String getDname() {
        return this.dname;
    }

    public void setDname(java.lang.String dname) {
        this.dname = dname;
    }

    public java.lang.String getLoc() {
        return this.loc;
    }

    public void setLoc(java.lang.String loc) {
        this.loc = loc;
    }

	public Set getEmployee() {
		return employee;
	}

	public void setEmployee(Set employee) {
		this.employee = employee;
	}
	
    public boolean equals(Object other) {
        if ( !(other instanceof Department) ) return false;
        Department castOther = (Department) other;
        return this.getDeptno() == castOther.getDeptno();
    }
    
    public String toString() {
    	StringBuffer buf = new StringBuffer();
    	buf.append("\n").append(deptno).append(", ");
		buf.append(dname).append(", ");
		buf.append(loc).append(",\n");
		buf.append(employee);
		
    	return buf.toString();
    }

    public int hashCode() {
        return (int) this.getDeptno();
    }
}
