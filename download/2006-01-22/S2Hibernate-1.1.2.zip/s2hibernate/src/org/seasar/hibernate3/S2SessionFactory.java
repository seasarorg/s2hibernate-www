package org.seasar.hibernate3;

import org.hibernate.Session;

/**
 * @author higa
 * @author kenichi_okazaki
 */
public interface S2SessionFactory {
    Session getSession();

    String getConfigPath();
}
