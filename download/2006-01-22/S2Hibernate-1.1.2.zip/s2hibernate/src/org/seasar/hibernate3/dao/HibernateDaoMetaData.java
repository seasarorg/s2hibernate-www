package org.seasar.hibernate3.dao;

import org.seasar.framework.beans.MethodNotFoundRuntimeException;

/**
 * @author kenichi_okazaki
 */
public interface HibernateDaoMetaData {
	
	public String BEAN_KEY = "BEAN";
	public String PROPERTY_KEY_SUFFIX = "_PROPERTY";
	public String ARGS_KEY_SUFFIX = "_ARGS";
	public String HQL_KEY_SUFFIX = "_HQL";
	public String LOCK_KEY_SUFFIX = "_LOCK";
	public String EAGER_KEY_SUFFIX = "_EAGER";
	
	public Class getBeanClass();
	
	public boolean hasHibernateCommand(String methodName);

	public HibernateCommand getHibernateCommand(String methodName)
		throws MethodNotFoundRuntimeException;
}
