package org.seasar.hibernate;


/**
 * @author higa
 * @author kenichi_okazaki
 */
public interface S2SessionFactory {

	public S2Session getSession();

	public String getConfigPath();

}
