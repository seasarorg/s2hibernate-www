package org.seasar.hibernate.dao.impl;

import org.seasar.hibernate.S2Session;
import org.seasar.hibernate.S2SessionFactory;
import org.seasar.hibernate.dao.HibernateCommand;

/**
 * @author kenichi_okazaki
 *
 */
public abstract class AbstractHibernateCommand implements HibernateCommand {

	private S2SessionFactory s2sessionFactory_;
	
	public AbstractHibernateCommand(S2SessionFactory s2sessionFactory) {
		s2sessionFactory_ = s2sessionFactory;
	}
	
	public S2Session getS2Session() {
		return s2sessionFactory_.getSession();
	}
}
