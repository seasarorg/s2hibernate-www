package org.seasar.hibernate.dao.impl;

import org.seasar.hibernate.S2Session;
import org.seasar.hibernate.S2SessionFactory;

/**
 * @author kenichi_okazaki
 */
public class SaveCommand extends AbstractHibernateCommand {

	public SaveCommand(S2SessionFactory s2sessionFactory) {
		super(s2sessionFactory);
	}

	/* (�� Javadoc)
	 * @see org.srasar.hibernate.dao.HibernateCommand#execute(org.seasar.hibernate.S2Session, java.lang.Object[])
	 */
	public Object execute( Object[] args) {
		S2Session s2session = getS2Session();
		s2session.save(args[0]);
		return null;
	}

}
