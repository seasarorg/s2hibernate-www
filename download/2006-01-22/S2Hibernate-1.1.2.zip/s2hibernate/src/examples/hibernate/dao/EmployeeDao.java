package examples.hibernate.dao;

import examples.hibernate.entity.Employee;

public interface EmployeeDao {

	public Employee getEmployee(int empno);
	
	public void save(Employee employee);
	
}
