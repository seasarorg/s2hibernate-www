package examples.hibernate.client;

import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.S2ContainerFactory;

import examples.hibernate.dao.EmployeeDao;



public class EmployeeClient {

	private static final String PATH =
		"examples/hibernate/client/Employee.dicon";
	public static void main(String[] args) {
		S2Container container = S2ContainerFactory.create(PATH);/* �菇1 */
		container.init();
		try {
			EmployeeDao dao =
				(EmployeeDao) container.getComponent(EmployeeDao.class);/* �菇2 */
			System.out.println(dao.getEmployee(7900).getEname());/* �菇3 */
			
//			Employee employee = new Employee();
//			employee.setEmpno(new Integer(7788));
//			employee.setEname("SCOTT");
//			dao.save(employee);
			
		} catch(Throwable t) {
			System.out.println("exeption:" + t);
		} finally {
			container.destroy();
		}

	}
}
