package examples.hibernate.dto;

import java.math.BigDecimal;

public class EmployeeSalDto {
	
	private BigDecimal fromSal;
	private BigDecimal toSal;

	public EmployeeSalDto() {
	}

	/**
	 * @return Returns the fromSal.
	 */
	public BigDecimal getFromSal() {
		return fromSal;
	}
	/**
	 * @param fromSal The fromSal to set.
	 */
	public void setFromSal(BigDecimal fromSal) {
		this.fromSal = fromSal;
	}
	/**
	 * @return Returns the toSal.
	 */
	public BigDecimal getToSal() {
		return toSal;
	}
	/**
	 * @param toSal The toSal to set.
	 */
	public void setToSal(BigDecimal toSal) {
		this.toSal = toSal;
	}
}
