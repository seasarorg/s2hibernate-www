package test.org.seasar.hibernate3.impl;

import java.io.Serializable;

/** @author Hibernate CodeGenerator */
public class Emp implements Serializable {
    private static final long serialVersionUID = 1L;

    /** identifier field */
    private long empno;

    /** nullable persistent field */
    private String ename;

    /** nullable persistent field */
    private String job;

    /** nullable persistent field */
    private Short mgr;

    /** nullable persistent field */
    private java.util.Date hiredate;

    /** nullable persistent field */
    private Float sal;

    /** nullable persistent field */
    private Float comm;

    /** nullable persistent field */
    private short deptno;

    /** full constructor */
    public Emp(long empno, java.lang.String ename, java.lang.String job, Short mgr, java.util.Date hiredate,Float sal, Float comm, short deptno) {
        this.empno = empno;
        this.ename = ename;
        this.job = job;
        this.mgr = mgr;
        this.hiredate = hiredate;
        this.sal = sal;
        this.comm = comm;
        this.deptno = deptno;
    }

    /** default constructor */
    public Emp() {
    }

    /** minimal constructor */
    public Emp(long empno) {
        this.empno = empno;
    }

    public long getEmpno() {
        return this.empno;
    }

    public void setEmpno(long empno) {
        this.empno = empno;
    }

    public java.lang.String getEname() {
        return this.ename;
    }

    public void setEname(java.lang.String ename) {
        this.ename = ename;
    }

    public java.lang.String getJob() {
        return this.job;
    }

    public void setJob(java.lang.String job) {
        this.job = job;
    }

    public Short getMgr() {
        return this.mgr;
    }

    public void setMgr(Short mgr) {
        this.mgr = mgr;
    }

    public java.util.Date getHiredate() {
        return this.hiredate;
    }

    public void setHiredate(java.util.Date hiredate) {
        this.hiredate = hiredate;
    }

    public Float getSal() {
        return this.sal;
    }

    public void setSal(Float sal) {
        this.sal = sal;
    }

    public Float getComm() {
        return this.comm;
    }

    public void setComm(Float comm) {
        this.comm = comm;
    }

    public short getDeptno() {
        return this.deptno;
    }

    public void setDeptno(short deptno) {
        this.deptno = deptno;
    }

    public boolean equals(Object other) {
        if ( !(other instanceof Emp) ) return false;
        Emp castOther = (Emp) other;
        return this.getEmpno() == castOther.getEmpno();
    }

    public int hashCode() {
        return (int) this.getEmpno();
    }

}
