
package test.org.seasar.hibernate.dao.impl;


public interface EmployeeService {
	public abstract void execute();
}