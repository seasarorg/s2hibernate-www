package org.seasar.hibernate.jpa;

public interface DepartmentDao {

    Department getDepartment1(int id);

    Department getDepartment2(int id);

    Department getDepartment3(int id);
}
